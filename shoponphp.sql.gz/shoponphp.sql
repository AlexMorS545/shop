-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Янв 28 2021 г., 16:16
-- Версия сервера: 5.6.47
-- Версия PHP: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shoponphp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `basket`
--

CREATE TABLE `basket` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `short_desc` text NOT NULL,
  `price` double NOT NULL,
  `image` text NOT NULL,
  `count` int(11) NOT NULL,
  `discount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `basket`
--

INSERT INTO `basket` (`id`, `name`, `short_desc`, `price`, `image`, `count`, `discount`) VALUES
(13, 'pixel', 'нет в наличии', 1400, 'pixel.jpg', 2, '0');

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--

CREATE TABLE `catalog` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `short_desc` text NOT NULL,
  `full_desc` text NOT NULL,
  `price` int(11) NOT NULL,
  `image` text NOT NULL,
  `status` int(11) NOT NULL,
  `discount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id`, `name`, `short_desc`, `full_desc`, `price`, `image`, `status`, `discount`) VALUES
(3, 'huawei', 'В наличии', 'Бюджетный телефон с мощным процессором', 600, 'huawei.jpg', 1, 0),
(5, 'oppo', 'в наличии', 'Новинка флагманского телефона', 850, 'oppo.jpg', 1, 0),
(6, 'samsung', 'в наличии', 'Современный телефон с хорошей камерой.', 1200, 'samsung.jpg', 1, 0),
(7, 'htc', 'под заказ', 'Большой объём батареи', 700, 'htc.jpg', 2, 0),
(9, 'asus', 'нет в наличии', 'К сожалению данного товара пока нет в наличии', 800, 'asus.jpg', 0, 0),
(10, 'iphone', 'в наличии', 'Новый телефон с хорошей камерой.', 1200, 'iphone.jpg', 1, 0),
(11, 'honor', 'в наличии', 'Новый прикольный телефон', 780, 'honor.jpg', 1, 0),
(12, 'GalaxyFold', 'под заказ', 'Телефон с большим экраном', 2200, 'GalaxyFold.jpg', 2, 0),
(13, 'pixel', 'нет в наличии', 'Телефон от google', 1400, 'pixel.jpg', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `data_creat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `comment`
--

INSERT INTO `comment` (`id`, `name`, `text`, `data_creat`) VALUES
(54, 'Андрей', 'Привет всем', '2020-11-17 17:55:44'),
(56, 'Ivan', 'Привет всем!', '2020-12-06 09:31:31'),
(59, 'Тася ', 'Отлично!', '2021-01-10 09:17:16'),
(60, 'Alex', 'Hello', '2021-01-23 11:49:33'),
(61, 'Андрей', 'Wolrd', '2021-01-23 11:50:14');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `password`, `role`) VALUES
(10, 'Alex', 'morsan20@yandex.ru', '07b432d25170b469b57095ca269bc202bec7b6bd40fc9229a12c69107b27380a', 0),
(12, 'admin', 'morsan20@bk.ru', '3cf108a4e0a498347a5a75a792f232123cf108a4e0a498347a5a75a792f23212', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `basket`
--
ALTER TABLE `basket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
